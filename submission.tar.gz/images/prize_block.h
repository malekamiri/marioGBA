/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=15x15 prize_block prize_block.png 
 * Time-stamp: Thursday 04/04/2019, 18:12:31
 * 
 * Image Information
 * -----------------
 * prize_block.png 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PRIZE_BLOCK_H
#define PRIZE_BLOCK_H

extern const unsigned short prize_block[225];
#define PRIZE_BLOCK_SIZE 450
#define PRIZE_BLOCK_LENGTH 225
#define PRIZE_BLOCK_WIDTH 15
#define PRIZE_BLOCK_HEIGHT 15

#endif

