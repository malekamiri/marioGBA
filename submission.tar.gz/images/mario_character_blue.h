/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x25 mario_character_blue mario_character_blue.png 
 * Time-stamp: Thursday 04/04/2019, 23:20:46
 * 
 * Image Information
 * -----------------
 * mario_character_blue.png 20@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MARIO_CHARACTER_BLUE_H
#define MARIO_CHARACTER_BLUE_H

extern const unsigned short mario_character_blue[500];
#define MARIO_CHARACTER_BLUE_SIZE 1000
#define MARIO_CHARACTER_BLUE_LENGTH 500
#define MARIO_CHARACTER_BLUE_WIDTH 20
#define MARIO_CHARACTER_BLUE_HEIGHT 25

#endif

