/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=35x112 flag_end flag_end.jpg 
 * Time-stamp: Friday 04/12/2019, 00:46:28
 * 
 * Image Information
 * -----------------
 * flag_end.jpg 35@112
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FLAG_END_H
#define FLAG_END_H

extern const unsigned short flag_end[3920];
#define FLAG_END_SIZE 7840
#define FLAG_END_LENGTH 3920
#define FLAG_END_WIDTH 35
#define FLAG_END_HEIGHT 112

#endif

