/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=35x35 mario_character mario_character.png 
 * Time-stamp: Thursday 04/04/2019, 04:07:07
 * 
 * Image Information
 * -----------------
 * mario_character.png 35@35
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MARIO_CHARACTER_H
#define MARIO_CHARACTER_H

extern const unsigned short mario_character[1225];
#define MARIO_CHARACTER_SIZE 2450
#define MARIO_CHARACTER_LENGTH 1225
#define MARIO_CHARACTER_WIDTH 35
#define MARIO_CHARACTER_HEIGHT 35

#endif

