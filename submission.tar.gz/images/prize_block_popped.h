/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=15x15 prize_block_popped prize_block_popped.png 
 * Time-stamp: Friday 04/05/2019, 15:04:05
 * 
 * Image Information
 * -----------------
 * prize_block_popped.png 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PRIZE_BLOCK_POPPED_H
#define PRIZE_BLOCK_POPPED_H

extern const unsigned short prize_block_popped[225];
#define PRIZE_BLOCK_POPPED_SIZE 450
#define PRIZE_BLOCK_POPPED_LENGTH 225
#define PRIZE_BLOCK_POPPED_WIDTH 15
#define PRIZE_BLOCK_POPPED_HEIGHT 15

#endif

