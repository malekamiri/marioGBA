/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=15x15 ground_block ground_block.png 
 * Time-stamp: Thursday 04/04/2019, 02:36:05
 * 
 * Image Information
 * -----------------
 * ground_block.png 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GROUND_BLOCK_H
#define GROUND_BLOCK_H

extern const unsigned short ground_block[225];
#define GROUND_BLOCK_SIZE 450
#define GROUND_BLOCK_LENGTH 225
#define GROUND_BLOCK_WIDTH 15
#define GROUND_BLOCK_HEIGHT 15

#endif

