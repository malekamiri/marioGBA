/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=18x18 ennemy mario_ennemy.png 
 * Time-stamp: Monday 04/08/2019, 23:01:10
 * 
 * Image Information
 * -----------------
 * mario_ennemy.png 18@18
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ENNEMY_H
#define ENNEMY_H

extern const unsigned short mario_ennemy[324];
#define MARIO_ENNEMY_SIZE 648
#define MARIO_ENNEMY_LENGTH 324
#define MARIO_ENNEMY_WIDTH 18
#define MARIO_ENNEMY_HEIGHT 18

#endif

