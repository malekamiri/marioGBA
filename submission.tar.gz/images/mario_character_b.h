/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=35x35 mario_character_b mario_character_b.png 
 * Time-stamp: Sunday 04/07/2019, 04:59:36
 * 
 * Image Information
 * -----------------
 * mario_character_b.png 35@35
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MARIO_CHARACTER_B_H
#define MARIO_CHARACTER_B_H

extern const unsigned short mario_character_b[1225];
#define MARIO_CHARACTER_B_SIZE 2450
#define MARIO_CHARACTER_B_LENGTH 1225
#define MARIO_CHARACTER_B_WIDTH 35
#define MARIO_CHARACTER_B_HEIGHT 35

#endif

