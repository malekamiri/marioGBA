/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=8x8 fireball fireball.jpg 
 * Time-stamp: Thursday 04/11/2019, 02:37:23
 * 
 * Image Information
 * -----------------
 * fireball.jpg 8@8
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FIREBALL_H
#define FIREBALL_H

extern const unsigned short fireball[64];
#define FIREBALL_SIZE 128
#define FIREBALL_LENGTH 64
#define FIREBALL_WIDTH 8
#define FIREBALL_HEIGHT 8

#endif

