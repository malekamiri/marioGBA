Super Mario Bros GBA

Use the arrows (LEFT and RIGHT) to move mario. Use UP to jump. Press A to throw fireballs.

You can hit the boxes to earn points.
Throw fireballs to kill Gumba. You can't jump on it.
Reach the flag to win!

Enjoy :)